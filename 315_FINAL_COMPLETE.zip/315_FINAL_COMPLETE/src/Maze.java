/*
* Name: Matthew Phelan
* Course: CS335 001
* Assignment: Program 2
* Last Modified: 10/26/18
 */
import javax.swing.*;

public class Maze extends JFrame {
    public static void main(String args[]){
        Generate s = new Generate();
        s.setVisible(true);
    }
}
