/*
* Name: Matthew Phelan
* Course: CS15 002
* Assignment: Final Project
* Last Modified: 12/10/18 1:18 AM
 */
import javax.swing.*;

public class Main extends JFrame {
    public static void main(String args[]){
        Generate s = new Generate();
        s.setVisible(true);
    }
}
